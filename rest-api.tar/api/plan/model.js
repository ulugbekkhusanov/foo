const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const PlanSchema = new mongoose.Schema({
    name: { type: String, minlength: 3, maxlength: 100, required: true },
    desc: { type: String, maxlength: 1000, default: '' },
    charge: { type: Number, min: 0, default: 0 }
});

PlanSchema.plugin(normalize);

const PlanModel = mongoose.model('Plan', PlanSchema, 'plan');

module.exports = {
    PlanSchema,
    PlanModel
}