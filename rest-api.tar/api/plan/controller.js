const { ErrorHandler } = require('../util/error');
const { PlanModel } = require('./model');

module.exports = {

    read: async function(req, res, next) {
        try {
            const docs = await PlanModel.find({}).exec();
            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to fetch all plans!'));
        }
    },
    
    create: async function(req, res, next) {
        try {
            const plan = new PlanModel(req.body);
            const doc = await plan.save();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to create new plan!'));
        }
    },

    update: async function(req, res, next) {
        try {
            const doc = await PlanModel.findByIdAndUpdate(req.params.id, req.body, {
                useFindAndModify: false, new: true
            }).exec();
            if(!doc) return next(new ErrorHandler(400, "Failed to update plan!"));
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception: Failed to update plan!"));
        }
    },

    delete: async function(req, res, next) {
        try {
            const doc = await PlanModel.findByIdAndDelete(req.params.id).exec();
            if(!doc) return next(new ErrorHandler(400, "Failed to delete plan!"));
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception: Failed to delete plan!"));
        }
    }

}