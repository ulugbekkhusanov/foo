const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    upsert: {
        body: {
            name: Joi.string().min(3).max(100).required(),
            desc: Joi.string().allow(['', null]).max(1000).default(''),
            charge: Joi.number().min(0).default(0)
        }
    }
}


router.use(authenticate);
router.use(permit('admin'));

// http://localhost:3000/api/plan
router.route('/').get(controller.read);
router.route('/').post(validate(Validator.upsert), controller.create);
router.route('/:id').put(validate(Validator.upsert), controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;