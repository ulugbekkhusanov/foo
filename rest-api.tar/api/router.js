const express = require('express');
const router = express.Router();


const adminRouter = require('./admin/router');
const storeRouter = require('./store/router');
const planRouter = require('./plan/router');
const userRouter = require('./user/router');
const tableRouter = require('./table/router');
const menuRouter = require('./menu/router');
const productRouter = require('./product/router');
const mediaRouter = require('./media/router');
const orderRouter = require('./order/router');
const historyRouter = require('./history/router');
const reportRouter = require('./report/router');
const feedbackRouter = require('./feedback/router');

 
router.use('/admin', adminRouter);
router.use('/store', storeRouter);
router.use('/plan', planRouter);
router.use('/user', userRouter);
router.use('/table', tableRouter);
router.use('/menu', menuRouter);
router.use('/product', productRouter);
router.use('/media', mediaRouter);
router.use('/order', orderRouter);
router.use('/history', historyRouter);
router.use('/report', reportRouter);
router.use('/feedback', feedbackRouter);

module.exports = router;