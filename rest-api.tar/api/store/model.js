const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');
const { UserSchema } = require('./../user/model');
const { MenuSchema } = require('../menu/model');
const { ProductSchema } = require('./../product/model');
const { MediaSchema } = require('./../media/model');
const { TableSchema } = require('./../table/model');


const StoreSchema = new mongoose.Schema({
    username: { type: String, minlength: 3, maxlength: 100, required: true, unique: true },
    password: { type: String, minlength: 3, maxlength: 100, required: true },
    info: { type: String, maxlength: 1000, default: '' },
    status: { type: Boolean, default: true },
    plan: { type: mongoose.Schema.Types.ObjectId, ref: 'Plan' },
    account_balance: { type: Number, default: 0 },
    user_limit: { type: Number, default: 3 },

    users: [UserSchema],
    tables: [TableSchema],
    menu: [MenuSchema],
    products: [ProductSchema],
    media: [MediaSchema]
});


StoreSchema.plugin(normalize);

const StoreModel = mongoose.model('Store', StoreSchema, 'store');

module.exports = {
    StoreSchema,
    StoreModel
}