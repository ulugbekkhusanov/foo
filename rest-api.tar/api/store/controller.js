const jwt = require('jsonwebtoken');
const bluebird = require('bluebird');
bluebird.promisifyAll(jwt);
const { ErrorHandler } = require('../util/error');
const { StoreModel } = require('./model');
const { encrypt, decrypt } = require('./../util/crypto-helper');

module.exports = {

    auth: async function (req, res, next) {
        try {
            let doc = await StoreModel.findOne({ username: req.body.username }, {
                users: 0, menu: 0, products: 0, tables: 0, media: 0
            }).exec();
            if (!doc) return next(new ErrorHandler(403, 'Error: Authentication failed!'));

            let psw = decrypt(doc.password);
            if (!(doc && doc.status && doc.account_balance > 0 && req.body.password === psw)) {
                return next(new ErrorHandler(403, 'Error: Authentication failed!'));
            }

            const jwt_token = jwt.sign({
                name: doc.username,
                role: 'store',
                store_id: doc.id
            }, process.env.TOKEN_SECRET_KEY, {
                algorithm: 'HS256',
                expiresIn: process.env.TOKEN_EXPIRESIN
            });

            return res.status(200).json({
                access_token: jwt_token
            });
        } catch (error) {
            return next(new ErrorHandler(403, 'Exception Error: Forbidden access!'));
        }
    },

    findAll: async function (req, res, next) {
        try {
            let docs = await StoreModel.find({},
                { users: 0, menu: 0, products: 0, media: 0, tables: 0 }).populate('plan').exec();
            if (!docs) return next(new ErrorHandler(400, 'Error: Failed to read stores'));

            docs.forEach(s => { s.password = decrypt(s.password); });
            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception Error: Failed to read stores"));
        }
    },

    create: async function (req, res, next) {
        try {
            req.body.password = encrypt(req.body.password);
            let doc = await StoreModel.create(req.body);
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to create store'));

            doc.password = decrypt(doc.password);
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception Error: Failed to create store"));
        }
    },

    update: async function (req, res, next) {
        try {
            req.body.password = encrypt(req.body.password);
            const doc = await StoreModel.findByIdAndUpdate(req.params.id, req.body, {
                projection: {
                    users: 0,
                    menu: 0,
                    products: 0,
                    media: 0,
                    tables: 0
                },
                useFindAndModify: false,
                new: true
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to update store'));

            doc.password = decrypt(doc.password);
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception Error: Failed to update store!"));
        }
    },

    delete: async function (req, res, next) {
        try {
            const doc = await StoreModel.findByIdAndDelete(req.params.id, {
                projection: {
                    users: 0,
                    menu: 0,
                    products: 0,
                    media: 0,
                    tables: 0
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to delete store'));

            doc.password = decrypt(doc.password);
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception Error: Failed to delete store"));
        }
    }

}