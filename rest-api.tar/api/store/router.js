const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');
const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    auth: {
        body: {
            username: Joi.string().min(3).max(100).required(),
            password: Joi.string().min(3).max(100).required(),
        }
    },

    upsert: {
        body: {
            username: Joi.string().min(3).max(100).required(),
            password: Joi.string().min(3).max(100).required(),
            status: Joi.boolean().default(true),
            info: Joi.string().max(1000).allow('', null),
            plan: Joi.string().max(100).allow('', null),
            user_limit: Joi.number().min(0).max(100).default(3),
            account_balance: Joi.number().min(0).default(0)
        }
    }
}

router.route('/auth').post(validate(Validator.auth), controller.auth);

router.use(authenticate);
router.use(permit('admin'));

router.route('/').get(controller.findAll);
router.route('/').post(validate(Validator.upsert), controller.create);
router.route('/:id').put(validate(Validator.upsert), controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;