const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const ProductSchema = new mongoose.Schema({
    name: { type: String, minlength: 3, maxlength: 100, required: true },
    desc: { type: String, maxlength: 1000, default: '' },
    media: { type: String, maxlength: 100, default: '' },
    status: { type: Boolean, default: true },
    menu: { type: String, maxlength: 100, default: '' },
    price: { type: Number, min: 0, default: 0 }
});

ProductSchema.plugin(normalize);

const ProductModel = mongoose.model('Product', ProductSchema, 'product');

module.exports = {
    ProductSchema,
    ProductModel
}