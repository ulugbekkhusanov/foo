const { ErrorHandler } = require('./../util/error');
const { StoreModel } = require('./../store/model');

module.exports = {
    findAll: async function (req, res, next) {
        try {
            const doc = await StoreModel.findById(req.identifier.store_id, { products: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to read products'));
            let result = doc.products || [];
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to read products'));
        }
    },

    create: async function (req, res, next) {
        try {
            const doc = await StoreModel.findByIdAndUpdate(req.identifier.store_id, {
                $push: { products: req.body }
            }, {
                new: true, useFindAndModify: false, projection: {
                    products: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to create product 1'));

            let product = doc.products.find(p => p.name === req.body.name);
            if (!product) return next(new ErrorHandler(400, 'Failed to create product 2'));
            return res.status(200).json(product);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create product'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'products._id': req.params.id
            }, {
                $set: {
                    'products.$.name': req.body.name,
                    'products.$.desc': req.body.desc,
                    'products.$.media': req.body.media,
                    'products.$.status': req.body.status,
                    'products.$.menu': req.body.menu,
                    'products.$.price': req.body.price
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    products: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to update product 1'));

            let product = doc.products.find(p => p.name === req.body.name);
            if (!product) return next(new ErrorHandler(400, 'Error: Failed to update product 2'));

            return res.status(200).json(product);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to update product'));
        }
    },

    delete: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'products._id': req.params.id
            }, {
                $pull: {
                    products: {
                        _id: req.params.id
                    }
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    products: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to delete product 1'));

            let product = doc.products.find(p => p.id === req.params.id);
            if (product) return next(new ErrorHandler(400, 'Error: Failed to delete product 2'));

            return res.status(200).json({ id: req.params.id });
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to delete product'));
        }
    }
}