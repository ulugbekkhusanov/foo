const Agenda = require('agenda');
const EventEmitter = require('events').EventEmitter;

const addHistory = require('./jobs/add-new-history');
const productBaseUpdate = require('./jobs/product-base-update');
const productUpdate = require('./jobs/product-update');
const productCsvUpload = require('./jobs/product-csv-upload');
const dailySummaryRecords = require('./jobs/daily-summary-records');
const monthlySummaryRecords = require('./jobs/monthly-summary-records');
const yearlySummaryRecords = require('./jobs/yearly-summary-record');
const filebackupDailyRecords = require('./jobs/filebackup-daily-records');


class AgendaJob {
    constructor() {
        this.JOB_TYPES = Object.freeze({
            ADD_HISTORY: "add history",
            PRODUCT_BASE_UPDATE: "product base update",
            PRODUCT_UPDATE: "product update",
            PRODUCT_CSV_UPLOAD: "product csv upload",
            DAILY_SUMMARY_RECORDS: "daily summary records",
            MONTHLY_SUMMARY_RECORDS: "monthly summary records",
            YEARLY_SUMMARY_RECORDS: "yearly summary records",
            FILEBACKUP_DAILY_RECORDS: 'filebackup daily records'
        });

        AgendaJob.singleton == null;
        this.emitter = new EventEmitter();
        this._connected = false;
        this._agenda = new Agenda({ db: { address: 'mongodb://localhost:27017/core-agenda' } });

        this._agenda.on("ready", () => {
            console.log('agenda ready!');
            this._connected = true;
            this.emitter.emit("ready");

            this._init();
            this._agenda.start();
        });
    }

    static getInstance() {
        if (AgendaJob.singleton == null) {
            AgendaJob.singleton = new AgendaJob();
        }
        return AgendaJob.singleton;
    }

    get connected() {
        return this._connected;
    }

    _init() {
        // ** Immediate Run */
        // this._agenda.define(this.JOB_TYPES.PRODUCT_BASE_UPDATE, productBaseUpdate);
        // this._agenda.define(this.JOB_TYPES.PRODUCT_UPDATE, productUpdate);
        this._agenda.define(this.JOB_TYPES.PRODUCT_CSV_UPLOAD, productCsvUpload);

        this._agenda.define(this.JOB_TYPES.ADD_HISTORY, addHistory);

        //* Daily Summary Records, runs every day at 01:00AM
        this._agenda.define(this.JOB_TYPES.DAILY_SUMMARY_RECORDS, dailySummaryRecords);
        this._agenda.every(process.env.DAILY_SUMMARY_RECORD_AT, this.JOB_TYPES.DAILY_SUMMARY_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.DAILY_SUMMARY_RECORDS);

        this._agenda.define(this.JOB_TYPES.FILEBACKUP_DAILY_RECORDS, filebackupDailyRecords);
        this._agenda.every(process.env.DAILY_FILEBACKUP_AT, this.JOB_TYPES.FILEBACKUP_DAILY_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.FILEBACKUP_DAILY_RECORDS);

        /** Monthly Run */
        // Monthly Summary Record, runs every day at 01:30AM
        // this._agenda.define(this.JOB_TYPES.MONTHLY_SUMMARY_RECORDS, monthlySummaryRecords);
        // this._agenda.every(process.env.MONTHLY_SUMMARY_RECORD_AT, this.JOB_TYPES.MONTHLY_SUMMARY_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.MONTHLY_SUMMARY_RECORDS);

        /** Yearly Run */
        // Yearly Summary Record, runs every day at 00:03AM
        // this._agenda.define(this.JOB_TYPES.YEARLY_SUMMARY_RECORDS, yearlySummaryRecords);
        // this._agenda.every(config.worker.yearlySummaryRecordAt, this.JOB_TYPES.GENERATE_YEARLY_SUMMARY_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.YEARLY_SUMMARY_RECORDS);

        

        /** Daily Run */
        //* Daily Records, runs every day at 12:30AM
        // this._agenda.define(this.JOB_TYPES.GENERATE_DAILY_RECORDS, generateDailyRecords);
        // this._agenda.every(config.worker.dailyRecordAt, this.JOB_TYPES.GENERATE_DAILY_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.GENERATE_DAILY_RECORDS)

        //* Backup daily-records into files as such: "storeID_userID_yyyy-mm-dd.json", runs at 02:00AM
        // this._agenda.define(this.JOB_TYPES.GENERATE_DAILY_FILEBACKUP_RECORDS, generateDailyFilebackupRecords);
        // this._agenda.every(config.worker.dailyFilebackupAt, this.JOB_TYPES.GENERATE_DAILY_FILEBACKUP_RECORDS, {}, { timezone: 'Asia/Tashkent', skipImmediate: true });
        // this._agenda.now(this.JOB_TYPES.GENERATE_DAILY_FILEBACKUP_RECORDS);
    }
}

module.exports = () => {
    return new Promise(((resolve) => {
        if (AgendaJob.getInstance().connected) {
            resolve(AgendaJob.getInstance());
        }
        else {
            AgendaJob.getInstance().emitter.on('ready', () => {
                resolve(AgendaJob.getInstance());
            })
        }
    }));
}