const moment = require('moment-timezone');
const { StoreModel } = require('./../../store/model');
const { HistorySummaryModel } = require('./../../history/model');
// const logger = require('./../utils/winston.logger');
const _ = require('lodash');

module.exports = async (job) => {
    try {
        let recordYear = moment().tz("Asia/Tashkent").subtract(1, 'day').format('YYYY');
        
        let stores = await StoreModel.find({}, { id: 1 }).exec();

        stores.forEach(async (store) => {
            try {
                let summaryDocs = await HistorySummaryModel.find({
                    store_id: store.id,
                    term: new RegExp('^' + recordYear +'-[0-9]{2}$')
                }).exec();

                let totalCash = 0;
                let totalCard = 0;
                let monthlyMap = [];
                let usersMap = {};

                summaryDocs.forEach(summary => {

                    totalCash += summary.totals.cash;
                    totalCard += summary.totals.card;

                    let markValue = (summary.term.split('-')[1]);

                    monthlyMap.push({
                        mark: markValue,
                        total: (summary.totals.cash + summary.totals.card)
                    });

                    let users = (summary && summary.users) ? summary.users : [];
                    users.forEach(user => {
                        if (!usersMap[user.user_id]) {
                            usersMap[user.user_id] = {
                                totals: {
                                    cash: 0,
                                    card: 0
                                },
                                intervals: []
                            };
                        }

                        usersMap[user.user_id].totals.cash += user.totals.cash;
                        usersMap[user.user_id].totals.card += user.totals.card;

                        usersMap[user.user_id].intervals.push({
                            mark: markValue,
                            total: (user.totals.cash + user.totals.card)
                        })
                    });
                });

                let usersData = Object.keys(usersMap).map(user_id => ({
                    user_id: user_id,
                    totals: usersMap[user_id].totals,
                    intervals: usersMap[user_id].intervals
                }));

                await HistorySummaryModel.findOneAndUpdate(
                    { term: recordYear, store_id: store.id },
                    {
                        term: recordYear,
                        store_id: store.id,
                        totals: {
                            cash: totalCash,
                            card: totalCard
                        },
                        intervals: monthlyMap,
                        users: usersData
                    },
                    {
                        upsert: true, new: true, setDefaultsOnInsert: true, useFindAndModify: false
                    }
                ).exec();

            } catch (err) {
                // logger.error(err);
                console.log(err);
            }

        });

    } catch (err) {
        console.log(err);
    }
}