const moment = require('moment-timezone');
// const logger = require('./../utils/winston.logger');
const delay = require('delay');
const _ = require('lodash');

const { StoreModel } = require('../../store/model');
const { HistoryModel, HistorySummaryModel } = require('../../history/model');


module.exports = async (job) => {
    try {
        let recordDate = moment().tz("Asia/Tashkent")
        .subtract(1, 'day')
        .format('YYYY-MM-DD');

        let stores = await StoreModel.find({}, { users: 1 }).exec();
        
        stores.forEach(async (store) => {
            let users = (store && store.users) ? store.users : [];
            users.forEach(async (user) => {
                try {
                    let dailyHistory = await HistoryModel.findOne({
                        date: recordDate,
                        store_id: store.id,
                        user_id: user.id
                    }, { records: 1 }).exec();

                    let totalCash = 0;
                    let totalCard = 0;
                    let hourlyMap = {};

                    let records = (dailyHistory && dailyHistory.records) ? dailyHistory.records : [];

                    records.forEach((record) => {

                        if (record.payment === 'cash') {
                            totalCash += record.total;
                        } else if (record.payment === 'card') {
                            totalCard += record.total;
                        }

                        let hourIndx = (new Date(record.timestamp)).getHours();
                        let count = hourlyMap[hourIndx] || 0;
                        hourlyMap[hourIndx] = count + record.total;
                    });

                    let hourlyData = Object.keys(hourlyMap).map(k => ({
                        mark: k,
                        total: hourlyMap[k]
                    }));

                    await HistorySummaryModel.findOneAndUpdate(
                        { term: recordDate, store_id: store.id },
                        {
                            $push: {
                                users: {
                                    user_id: user.id,
                                    totals: {
                                        cash: totalCash,
                                        card: totalCard
                                    },
                                    intervals: hourlyData
                                }
                            }
                        },
                        { new: true, upsert: true, useFindAndModify: false, setDefaultsOnInsert: true }
                    ).exec();
                    
                } catch (err) {
                    // logger.error(err);
                    console.log('Exception 0: ', err);
                }
            });



            // Calculate totals for selected Store
            try {

                // Intentional delay to set DB settle down
                await delay(5000);

                let historySummary = await HistorySummaryModel.findOne({
                    store_id: store.id,
                    term: recordDate
                }, { users: 1 }).exec();

                let userList = (historySummary && historySummary.users) ? historySummary.users : [];
                let storeTotals = userList.reduce((acc, user) => {
                    let cashTotal = acc.cash + user.totals.cash;
                    let cardTotal = acc.card + user.totals.card;
                    return {
                        cash: cashTotal,
                        card: cardTotal
                    }
                }, {
                    cash: 0,
                    card: 0
                });

                // 
                let hourlyMap = _.flatten(_.map(userList, (user) => user.intervals)).reduce((acc, item) => {
                    let count = acc[item.mark] || 0;
                    acc[item.mark] = count + item.total;
                    return acc;
                }, []);

                let hourlyData = Object.keys(hourlyMap).map(k => ({
                    mark: k,
                    total: hourlyMap[k]
                }))

                await HistorySummaryModel.findOneAndUpdate({
                        store_id: store.id,
                        term: recordDate
                    }, {
                        $set: {
                            intervals: hourlyData,
                            totals: storeTotals
                        }
                    }, { new: true, upsert: true, useFindAndModify: false, setDefaultsOnInsert: true }
                ).exec();

            } catch (err) {
                // logger.error(err);
                console.log('Exception 1: ', err);
            }
        });

    } catch (err) {
        // logger.error(err);
        console.log('Exception 2: ', err);
    }
}