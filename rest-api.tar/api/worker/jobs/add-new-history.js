const _ = require('lodash');
const moment = require('moment-timezone');
// const logger = require('./../utils/winston.logger');

const { StoreModel } = require('./../../store/model');
const { HistoryModel } = require('./../../history/model');

module.exports = async (job) => {
    try {
        const message = job.attrs.data; // req.body
        const date = moment().tz("Asia/Tashkent").format('YYYY-MM-DD');
        const store_id = message.store_id;
        const user_id = message.user_id;
        const records = message.records || [];

        // Step 1
        const doc = await HistoryModel.findOneAndUpdate({
            date: date,
            store_id: store_id,
            user_id: user_id
        }, {
            $push: {
                records: {
                    $each: records
                }
            }
        }, {
            new: true,
            upsert: true,
            setDefaultsOnInsert: true,
            useFindAndModify: false
        }).exec();

        // Step 2
        let productMap = _.flatten(_.map(records, (record) => record.items)).reduce((acc, item) => {
            let count = acc[item.product_id] || 0;
            acc[item.product_id] = count + item.quantity;
            return acc;
        }, []);

        // Step 3
        let store = await StoreModel.findById(store_id, { products: 1 }).exec();
        store.products.forEach(p => {
            if (!!productMap[p.id]) {
                p.amount -= productMap[p.id];
                if(p.amount < 1) p.status = false;
            }
        });

        await store.save();
    } catch (error) {
        console.log(error);
    }
}