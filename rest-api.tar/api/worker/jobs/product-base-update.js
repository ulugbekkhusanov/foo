// const { ProductModel } = require('../../product/model');
// const { CategoryModel } = require('../../category/model');

// module.exports = async (job) => {
//     try {
//         let productDocs = await ProductModel.find({}, { category: 1 }).exec();
//         let countMap = [];
//         productDocs.forEach(p => {
//             if (p && p.category) {
//                 countMap[p.category] = (countMap[p.category]) ? countMap[p.category] + 1 : 1;
//             }
//         });

//         let categoryDocs = await CategoryModel.find({}).exec();
//         for (let i = 0; i < categoryDocs.length; i++) {
//             let id = categoryDocs[i].id;
//             let count = (countMap[id]) ? (countMap[id]) : 0;
//             await CategoryModel.findByIdAndUpdate(id, {
//                 count: count
//             }, {
//                 useFindAndModify: false
//             })
//         }
//     } catch (error) {
//         console.log(error)
//     }
// }