const _ = require('lodash');
const moment = require('moment-timezone');
// const logger = require('./../utils/winston.logger');

const { StoreModel } = require('../../store/model');
const { HistorySummaryModel } = require('./../../history/model');

module.exports = async (job) => {
    try {
        let recordMonth = moment().tz("Asia/Tashkent").subtract(1, 'day').format('YYYY-MM');
        let stores = await StoreModel.find({}, { id: 1 }).exec();
        stores.forEach(async (store) => {
            try {

                let totalCash = 0;
                let totalCard = 0;
                let dailyMap = [];

                let usersMap = {};

                let summaryDocs = await HistorySummaryModel.find({ 
                    store_id: store.id, 
                    term: new RegExp('^' + recordMonth +'-[0-9]{2}$')
                }).exec();
                
                summaryDocs.forEach(summary => {
                    
                    totalCash += summary.totals.cash;
                    totalCard += summary.totals.card;

                    let markValue = (summary.term.split('-')[2]);
                    
                    dailyMap.push({
                        mark: markValue,
                        total: (summary.totals.cash + summary.totals.card)
                    });

                    let users = (summary && summary.users) ? summary.users : [];
                    users.forEach(user => {
                        if (!usersMap[user.user_id]) {
                            usersMap[user.user_id] = {
                                totals: {
                                    cash: 0,
                                    card: 0
                                },
                                intervals: []
                            };
                        }

                        usersMap[user.user_id].totals.cash += user.totals.cash;
                        usersMap[user.user_id].totals.card += user.totals.card;

                        usersMap[user.user_id].intervals.push({
                            mark: markValue,
                            total: (user.totals.cash + user.totals.card)
                        })
                    });
                });

                let usersData = Object.keys(usersMap).map(user_id => ({
                    user_id: user_id,
                    totals: usersMap[user_id].totals,
                    intervals: usersMap[user_id].intervals
                }));

                await HistorySummaryModel.findOneAndUpdate(
                    { term: recordMonth, store_id: store.id },
                    {
                        term: recordMonth,
                        store_id: store.id,
                        totals: {
                            cash: totalCash,
                            card: totalCard
                        },
                        intervals: dailyMap,
                        users: usersData
                    },
                    {
                        upsert: true, new: true, setDefaultsOnInsert: true, useFindAndModify: false
                    }
                ).exec();

            } catch (err) {
                // logger.error(err);
                console.log('Exception 2: ', err)
            }

        });

    } catch (err) {
        // logger.error(err);
        console.log('Exception 2: ', err)
    }
}