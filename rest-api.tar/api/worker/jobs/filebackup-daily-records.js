const jsonfile = require('jsonfile');
const moment = require('moment-timezone');
const appRoot = require('app-root-path');
// const logger = require('./../utils/winston.logger');
const { StoreModel } = require('../../store/model');
const { HistoryModel } = require('../../history/model');

module.exports = async (job) => {
    try {
        let recordDate = moment().tz("Asia/Tashkent").subtract(1, 'day').format('YYYY-MM-DD');
        const basePath = `${appRoot}/backups/`;

        let stores = await StoreModel.find({}, { username: 1, users: 1 }).exec();

        stores.forEach(async (store) => {
            let users = (store && store.users) ? store.users : [];
            users.forEach(async (user) => {
                try {
                    let dailyHistory = await HistoryModel.findOne({
                        date: recordDate,
                        store_id: store.id,
                        user_id: user.id
                    }).exec();

                    if (dailyHistory) {
                        let fileName = basePath + store.username + '_' + user.name + '_' + recordDate + '.json';
                        await jsonfile.writeFile(fileName, dailyHistory);
                    }
                } catch (err) {
                    // logger.error(err);
                    console.log(err);
                }
            });
        });

    } catch (err) {
        // logger.error(err);
        console.log(err);
    }
}