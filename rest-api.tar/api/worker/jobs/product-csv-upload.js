const appRoot = require('app-root-path');
const { ProductModel } = require('../../product/model');

module.exports = async (job) => {
    try {
        if (job.attrs.data && job.attrs.data.store_id && job.attrs.data.filename) {
            const store_id = job.attrs.data.store_id;
            const file_path = appRoot + '/uploads/' + job.attrs.data.filename;

            // Read csv file, parse, generate json, save to Product
            // if product entry has id, try to update, without id insert
            // findByIdAndUpdate has upser:true option, maybe it will work


        }
        
    } catch (error) {
        console.log(error)
    }
}