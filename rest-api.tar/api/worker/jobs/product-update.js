const { StoreModel } = require('../../store/model');

module.exports = async (job) => {
    try {
        if (job.attrs.data && job.attrs.data.store) {
            const store = job.attrs.data.store;
            const products = store.products || [];
            const categories = store.categories || [];

            let countMap = [];
            products.forEach(p => {
                if (p && p.category) {
                    countMap[p.category] = (countMap[p.category]) ? countMap[p.category] + 1 : 1;
                }
            });

            for (let i = 0; i < categories.length; i++) {
                let count = (countMap[categories[i]._id]) ? (countMap[categories[i]._id]) : 0;
                await StoreModel.findOneAndUpdate({
                    _id: store._id,
                    'categories._id': categories[i]._id
                }, {
                    $set: {
                        'categories.$.count': count
                    }
                }, { useFindAndModify: false }).exec();
            }

        }

    } catch (error) {
        console.log(error)
    }
}