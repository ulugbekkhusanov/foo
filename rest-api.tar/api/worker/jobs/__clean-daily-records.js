const jsonfile = require('jsonfile');
const moment = require('moment-timezone');
const { StoreModel } = require('./../../store/model');
const { HistoryModel } = require('./../../history/model');
// const logger = require('./../../utils/winston.logger');

module.exports = async (job) => {
    try {
        let date = moment().tz("Asia/Tashkent").subtract(1, 'day').format('YYYY-MM-DD');
        
        
        
    } catch (err) {
        // logger.error(err);
    }
}