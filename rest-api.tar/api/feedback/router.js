const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    upsert: {
        body: {
            store: Joi.string().max(100),
            title: Joi.string().min(3).max(100).required(),
            message: Joi.string().min(3).max(1000).required(),
            rating: Joi.number().min(1).max(5).default(1),
            status: Joi.string().max(100).allow('').default('')
        }
    }
}

router.use(authenticate);
router.route('/').post(validate(Validator.upsert), controller.create);

router.route('/store').get(permit('store', 'user'), controller.findAllByStore);

router.use(permit('admin'));
router.route('/').get(controller.findAll);
router.route('/:id').put(controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;