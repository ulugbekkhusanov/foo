const { ErrorHandler } = require('../util/error');
const { FeedbackModel } = require('./model');

module.exports = {

    findAll: async function (req, res, next) {
        try {
            const docs = await FeedbackModel.find({}).exec();
            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to fetch all feedbacks!'));
        }
    },

    findAllByStore: async function (req, res, next) {
        try {
            const docs = await FeedbackModel.find({
                store: req.identifier.store_id
            }).exec();
            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to fetch all feedbacks!'));
        }
    },

    create: async function (req, res, next) {
        try {
            req.body.store = req.identifier.store_id;
            const feedback = new FeedbackModel(req.body);
            const doc = await feedback.save();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to create new feedback!'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await FeedbackModel.findByIdAndUpdate(req.params.id, {
                status: req.body.status
            }, { useFindAndModify: false, new: true }).exec();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception: Failed to create new feedback!'));
        }
    },

    delete: async function (req, res, next) {
        try {
            const doc = await FeedbackModel.findByIdAndDelete(req.params.id).exec();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception: Failed to delete feedback!"));
        }
    }

}