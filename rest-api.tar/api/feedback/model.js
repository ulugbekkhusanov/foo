const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const FeedbackSchema = new mongoose.Schema({
    store: { type: mongoose.Schema.Types.ObjectId, ref: 'Store' },
    title: { type: String, minlength: 3, maxlength: 100, required: true },
    message: { type: String, minlength: 3, maxlength: 1000, required: true },
    rating: { type: Number, min: 1, max: 5, default: 1 },
    status: { type: String, maxlength: 100, default: '' }
}, { timestamps: true });

FeedbackSchema.plugin(normalize);

const FeedbackModel = mongoose.model('Feedback', FeedbackSchema, 'feedback');

module.exports = {
    FeedbackSchema,
    FeedbackModel
}