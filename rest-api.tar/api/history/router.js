const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    create: {
        body: {
            table: Joi.string().max(100).required(),
            seats: Joi.number().max(100),
            checkin: Joi.string(),
            checkout: Joi.string(),
            payment: Joi.string().max(100),
            total: Joi.number(),
            items: Joi.array().default([])
        }
    }
}

router.use(authenticate);

router.route('/dates').get(permit('store'), controller.getDates);
router.route('/').get(permit('store'), controller.findAll);

router.route('/user/dates').get(permit('user'), controller.getUserDates);
router.route('/user').get(permit('user'), controller.findAllByUser);
router.route('/').post(permit('user'), validate(Validator.create), controller.create);

module.exports = router;