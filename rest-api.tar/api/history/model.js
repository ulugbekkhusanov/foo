const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const HistorySchema = new mongoose.Schema({
    date: String,
    store_id: String,
    user_id: String,
    records: [{
        _id: false,
        table: String,
        seats: Number,
        checkin: String,
        checkout: String,
        payment: String,
        total: { type: Number, min: 0 },
        items: [{
            _id: false,
            product_id: { type: String },
            product_name: { type: String, default: "" },
            product_price: { type: Number, default: 0 },
            quantity: { type: Number, default: 1 },
            total: { type: Number, default: 0 }
        }]
    }]
});

HistorySchema.plugin(normalize);
const HistoryModel = mongoose.model('History', HistorySchema, 'history');

module.exports = {
    HistorySchema,
    HistoryModel
}