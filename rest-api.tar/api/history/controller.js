const AgendaJob = require('./../worker/agenda');
const moment = require('moment-timezone');
const { ErrorHandler } = require('./../util/error');
const { HistoryModel } = require('./model');

module.exports = {
    // Store controllers
    getDates: async function (req, res, next) {
        try {
            const docs = await HistoryModel.find({
                store_id: req.identifier.store_id
            }, { date: 1 }).exec();

            let dates = docs.map(doc => doc.date);
            return res.status(200).json(dates);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get history dates'));
        }
    },

    findAll: async function (req, res, next) {
        try {
            const { date } = req.query;
            if (!date) return next(new ErrorHandler(400, 'Error: Failed to get history'));

            const docs = await HistoryModel.find({
                store_id: req.identifier.store_id,
                date: date
            }).exec();

            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get history'));
        }
    },

    // User controllers
    getUserDates: async function (req, res, next) {
        try {
            const docs = await HistoryModel.find({
                store_id: req.identifier.store_id,
                user_id: req.identifier.user_id
            }, { date: 1 }).exec();

            let dates = docs.map(doc => doc.date);
            return res.status(200).json(dates);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get history dates'));
        }
    },

    findAllByUser: async function (req, res, next) {
        try {
            const { date } = req.query;
            if (!date) return next(new ErrorHandler(400, 'Error: Failed to get history'));

            const doc = await HistoryModel.findOne({
                store_id: req.identifier.store_id,
                user_id: req.identifier.user_id,
                date: date
            }).exec();
            
            return res.status(200).json(doc.records);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get history'));
        }
    },

    create: async function (req, res, next) {
        try {
            const recordDate = moment().tz("Asia/Tashkent").format('YYYY-MM-DD');
            const doc = await HistoryModel.findOneAndUpdate({
                date: recordDate,
                store_id: req.identifier.store_id,
                user_id: req.identifier.user_id
            }, {
                $push: {
                    records: req.body
                }
            }, {
                new: true,
                upsert: true,
                setDefaultsOnInsert: true,
                useFindAndModify: false
            }).exec();
            if(!doc) return next(new ErrorHandler(400, 'Error: Failed to create history'));

            return res.status(200).json({
                message: "orders are added to history"
            });
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create history'));
        }
    }
}








// async function create(req, res, next) {
//     try {
//         const worker = await AgendaJob();
//         worker._agenda.now(worker.JOB_TYPES.ADD_HISTORY, req.body);

//         return res.status(200).json({
//             status: "successfully received!"
//         });
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Exception: Failed to create history'));
//     }
// }

// async function dateTime(req, res, next) {
//     try {
//         const docs = await HistoryModel.find({
//             store_id: req.body.store_id,
//             user_id: req.body.user_id
//         }, { date: 1 }).exec();

//         let dates = docs.map(d => d.date) || [];

//         const summaryDocs = await HistorySummaryModel.find({
//             store_id: req.body.store_id
//         }, { term: 1 }).exec();

//         let terms = summaryDocs.map(d => d.term);
//         let days = terms.filter(t => /(\d{4})-(\d{2})-(\d{2})/.test(t)) || [];
//         let months = terms.filter(t => /(^\d{4})-(\d{2}$)/.test(t)) || [];
//         let years = terms.filter(t => /(^\d{4}$)/.test(t)) || [];

//         return res.status(200).json({
//             dates,
//             days,
//             months,
//             years
//         });
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Exception: Failed to available'));
//     }
// }

// // req.body = { date, store_id, user_id }
// async function daily(req, res, next) {
//     try {
//         const date = moment(req.body.date).tz("Asia/Tashkent").format('YYYY-MM-DD');
//         const doc = await HistoryModel.findOne({
//             date: date,
//             store_id: req.body.store_id,
//             user_id: req.body.user_id
//         }, { records: 1 }).exec();

//         let list = doc.records || [];
//         return res.status(200).json(list);
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Failed to fetch daily history data'));
//     }
// }

// // req.body = { criteria, date, store_id, user_id }
// async function summary(req, res, next) {
//     try {
//         let term;
//         switch (req.body.criteria) {
//             case 'year':
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY');
//                 break;

//             case 'month':
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY-MM');
//                 break;

//             default:
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY-MM-DD');
//                 break;
//         }

//         const doc = await HistorySummaryModel.findOne({
//             store_id: req.body.store_id,
//             term: term
//         }).exec();

//         if (req.user.role === 'store' && req.body.user_id === "all") {
//             return res.status(200).json({ totals: doc.totals, intervals: doc.intervals })
//         }

//         if (doc && doc.users) {
//             let user = doc.users.find(u => u.user_id === req.body.user_id);
//             if (!user) return next(new ErrorHandler(400, 'Failed to fetch user summary data '));
//             return res.status(200).json({
//                 totals: user.totals,
//                 intervals: user.intervals
//             });
//         }
//         return next(new ErrorHandler(400, 'Failed to fetch summary data'));
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Excaption: Failed to fetch daily summary history data'));
//     }
// }





// async function storeDateTime(req, res, next) {
//     try {
//         const docs = await HistoryModel.find({ store_id: req.user.id }, { date: 1 }).exec();
//         let dates = docs.map(d => d.date) || [];

//         const summaryDocs = await HistorySummaryModel.find({
//             store_id: req.user.id
//         }, { term: 1 }).exec();

//         let terms = summaryDocs.map(d => d.term);
//         let days = terms.filter(t => /(\d{4})-(\d{2})-(\d{2})/.test(t)) || [];
//         let months = terms.filter(t => /(^\d{4})-(\d{2}$)/.test(t)) || [];
//         let years = terms.filter(t => /(^\d{4}$)/.test(t)) || [];

//         return res.status(200).json({
//             dates,
//             days,
//             months,
//             years
//         });
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Exception: Failed to available'));
//     }
// }


// async function storeSummary(req, res, next) {
//     try {
//         let term;
//         switch (req.body.criteria) {
//             case 'year':
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY');
//                 break;

//             case 'month':
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY-MM');
//                 break;

//             default:
//                 term = moment(req.body.date).tz("Asia/Tashkent").format('YYYY-MM-DD');
//                 break;
//         }

//         const doc = await HistorySummaryModel.findOne({
//             store_id: req.user.id,
//             term: term
//         }, { products: 0 }).exec();

//         return res.status(200).json(doc);
//     } catch (error) {
//         return next(new ErrorHandler(400, 'Excaption: Failed to fetch daily summary history data'));
//     }
// }




// module.exports = {
//     dateTime,
//     create,
//     daily,
//     summary,

//     storeDateTime,
//     storeSummary
// }