const express = require('express');
const router = express.Router();
const controller = require('./controller');
const appRoot = require('app-root-path');
const multer = require('multer');
const crypto = require('crypto');
const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const upload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, appRoot + process.env.PUBLIC_FOLDER)
        },
        filename: (req, file, cb) => {
            let customFileName = crypto.randomBytes(8).toString('hex');
            let fileExtension = file.originalname.split('.')[1];
            cb(null, customFileName + '.' + fileExtension)
        }
    })
});

router.use(authenticate);

router.use(permit('store', 'user'));
router.route('/').get(controller.findAll);

router.use(permit('store'));
router.route('/').post(upload.array('files', 10), controller.upload);
router.route('/:id').delete(controller.delete);

module.exports = router;