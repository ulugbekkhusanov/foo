const { ErrorHandler } = require('./../util/error');
const { StoreModel } = require('./../store/model');
const fs = require('fs');
const { promisify } = require('util');
const deleteFileAsync = promisify(fs.unlink);
const appRoot = require('app-root-path');
const _ = require('lodash');

module.exports = {

    findAll: async function (req, res, next) {
        try {
            const doc = await StoreModel.findById(req.identifier.store_id, { media: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to fetch media list'));
            let result = doc.media || [];
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to fetch media list'));
        }
    },

    upload: async function (req, res, next) {
        try {
            let mediaData = [];
            if (req.files && req.files.length > 0) {
                for (let i = 0; i < req.files.length; i++) {
                    mediaData.push({
                        name: req.files[i].originalname,
                        filename: req.files[i].filename,
                        menu: req.body.menu,
                    });
                }
            }

            // return Error if no files loaded
            if (!mediaData.length) return next(new ErrorHandler(400, 'Error: Media upload not successful'));

            const doc = await StoreModel.findById(req.identifier.store_id, { media: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Media upload failed 1!'));

            doc.media = _.concat(doc.media, mediaData);
            let updatedDoc = await doc.save();
            if (!updatedDoc) return next(new ErrorHandler(400, 'Error: Media upload failed 2!'));

            let uploadFiles = mediaData.map(m => m.name);
            let mediaFiles = updatedDoc.media.filter(m => (uploadFiles.includes(m.name)));
            return res.status(200).json(mediaFiles);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: failed to create media'));
        }
    },

    delete: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'media._id': req.params.id
            }, {
                $pull: {
                    media: {
                        _id: req.params.id
                    }
                }
            }, {
                new: false, useFindAndModify: false, projection: {
                    media: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Media delete failed 1!'));

            let media = doc.media.find(m => m.id === req.params.id);
            if (!media) return next(new ErrorHandler(400, 'Error: Media delete failed 2!'));

            await deleteFileAsync(appRoot + process.env.PUBLIC_FOLDER + '/' + media.filename);
            
            return res.status(200).json(media);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: failed to delete media!'));
        }
    }
}