const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const MediaSchema = new mongoose.Schema({
    name: { type: String, required: true },
    filename: { type: String, required: true },
    menu: { type: String, maxlength: 100, default: null, required: true }
});

MediaSchema.plugin(normalize);

const MediaModel = mongoose.model('Media', MediaSchema, 'media');

module.exports = {
    MediaSchema,
    MediaModel
}

