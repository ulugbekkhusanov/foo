const AgendaJob = require('../worker/agenda');
const moment = require('moment-timezone');
const { ErrorHandler } = require('../util/error');
const { ReportModel } = require('./model');

module.exports = {

    getDates: async function (req, res, next) {
        try {
            const docs = await ReportModel.find({
                store_id: req.identifier.store_id
            }, { date: 1 }).exec();
            if (!docs) return next(new ErrorHandler(400, 'Error: Failed to get report dates'));

            let result = docs.map(doc => doc.date);
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get report dates'));
        }
    },

    findByUser: async function (req, res, next) {
        try {
            const { date } = req.query;
            if (!date) return next(new ErrorHandler(400, 'Error: Failed to get reports!'));

            const doc = await ReportModel.findOne({
                store_id: req.identifier.store_id,
                date: date
            }, { products: 0 }).exec();

            return res.status(200).json(doc);

        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get reports!'));
        }
    },

    findByProduct: async function (req, res, next) {
        try {
            const { date } = req.query;
            if (!date) return next(new ErrorHandler(400, 'Error: Failed to get reports!'));

            const doc = await ReportModel.findOne({
                store_id: req.identifier.store_id,
                date: date
            }, { users: 0 }).exec();

            return res.status(200).json(doc);

        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to get reports!'));
        }
    }
}