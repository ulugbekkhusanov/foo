const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

// 
router.use(authenticate);
router.use(permit('store'));

router.route('/dates').get(controller.getDates);

router.route('/user').get(controller.findByUser);

router.route('/product').get(controller.findByProduct);

module.exports = router;