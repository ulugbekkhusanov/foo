const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const ReportSchema = new mongoose.Schema({
    store_id: String,
    date: String,   // '2020-05-17' / '2020-03' / '2020-04' / '2017' / '2018' / '2020'
    totals: {
        cash: { type: Number, min: 0 }, // 'naqd pullar jami'
        card: { type: Number, min: 0 }
    },
    intervals: [{
        _id: false,
        mark: { type: Number, min: 0 }, // 'hour' /   day /   month
        total: { type: Number, min: 0 }
    }],
    users: [{
        _id: false,
        user_id: String,
        totals: {
            cash: { type: Number, min: 0 },
            card: { type: Number, min: 0 }
        },
        intervals: [{
            _id: false,
            mark: { type: Number, min: 0 }, // hour /   day /   month
            total: { type: Number, min: 0 }
        }]
    }],

    products: [{
        _id: false,
        product_name: String,
        totals: { type: Number, min: 0 },
        intervals: [{
            _id: false,
            mark: { type: Number, min: 0 }, // hour /   day /   month
            total: { type: Number, min: 0 }
        }]
    }]
});

ReportSchema.plugin(normalize);
const ReportModel = mongoose.model('Report', ReportSchema, 'report');

module.exports = {
    ReportSchema,
    ReportModel
}