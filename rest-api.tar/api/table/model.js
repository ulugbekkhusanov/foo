const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const TableSchema = new mongoose.Schema({
    name: { type: String, required: true, min: 3, max: 100 },
    desc: { type: String, maxlength: 1000, default: '' },
    media: { type: String, maxlength: 100, default: '' },
    status: { type: Boolean, default: true },
    seats: { type: Number, min: 0, default: 0 }
});

TableSchema.plugin(normalize);

const TableModel = mongoose.model('Table', TableSchema, 'table');

module.exports = {
    TableSchema,
    TableModel
}