const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    upsert: {
        body: {
            id: Joi.string(),
            name: Joi.string().min(3).max(100).required(),
            desc: Joi.string().allow('', null).default(''),
            media: Joi.string().allow('', null).default(''),
            status: Joi.boolean().default(true),
            seats: Joi.number().min(0).default(0)
        }
    }
}

router.use(authenticate);

router.use(permit('store', 'user'));
router.route('/').get(controller.findAll);

router.use(permit('store'));
router.route('/').post(validate(Validator.upsert), controller.create);
router.route('/:id').put(validate(Validator.upsert), controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;