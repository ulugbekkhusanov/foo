const { ErrorHandler } = require('../util/error');
const { StoreModel } = require('../store/model');

module.exports = {
    findAll: async function (req, res, next) {
        try {
            const doc = await StoreModel.findById(req.identifier.store_id, { tables: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to read tables'));
            let result = doc.tables || [];
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to read tables'));
        }
    },

    create: async function (req, res, next) {
        try {
            const doc = await StoreModel.findByIdAndUpdate(req.identifier.store_id, {
                $push: { tables: req.body }
            }, {
                new: true, useFindAndModify: false, projection: {
                    tables: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to create table 1'));

            let table = doc.tables.find(t => t.name === req.body.name);
            if (!table) return next(new ErrorHandler(400, 'Error: Failed to create table 2'));
            return res.status(200).json(table);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create table'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'tables._id': req.params.id
            }, {
                $set: {
                    'tables.$.name': req.body.name,
                    'tables.$.desc': req.body.desc,
                    'tables.$.media': req.body.media,
                    'tables.$.status': req.body.status,
                    'tables.$.seats': req.body.seats
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    tables: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to update table 1'));

            let table = doc.tables.find(t => t.name === req.body.name);
            if (!table) return next(new ErrorHandler(400, 'Error: Failed to update table 2'));
            return res.status(200).json(table);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to update table'));
        }
    },

    delete: async function(req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'tables._id': req.params.id
            }, {
                $pull: {
                    tables: {
                        _id: req.params.id
                    }
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    tables: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to delete table 1'));
    
            let table = doc.tables.find(t => t.id === req.params.id);
            if (!table) return res.status(200).json({ id: req.params.id });
            
            return next(new ErrorHandler(400, 'Error: Failed to delete table 2'));
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to delete table'));
        }
    }

}