const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const MenuSchema = new mongoose.Schema({
    name: { type: String, required: true, min: 3, max: 100 },
    desc: { type: String, maxlength: 1000, default: '' },
    media: { type: String, maxlength: 100, default: '' },
    status: { type: Boolean, default: true }
});

MenuSchema.plugin(normalize);

const MenuModel = mongoose.model('Menu', MenuSchema, 'menu');

module.exports = {
    MenuSchema,
    MenuModel
}