const { ErrorHandler } = require('../util/error');
const { StoreModel } = require('../store/model');

module.exports = {
    findAll: async function (req, res, next) {
        try {
            const doc = await StoreModel.findById(req.identifier.store_id, { menu: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to read menu'));
            let result = doc.menu || [];
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to read menu'));
        }
    },

    create: async function (req, res, next) {
        try {
            const doc = await StoreModel.findByIdAndUpdate(req.identifier.store_id, {
                $push: { menu: req.body }
            }, {
                new: true, useFindAndModify: false, projection: {
                    menu: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to create menu 1'));

            let menu = doc.menu.find(c => c.name === req.body.name);
            if (!menu) return next(new ErrorHandler(400, 'Error: Failed to create menu 2'));
            return res.status(200).json(menu);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create menu'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'menu._id': req.params.id
            }, {
                $set: {
                    'menu.$.name': req.body.name,
                    'menu.$.desc': req.body.desc,
                    'menu.$.media': req.body.media,
                    'menu.$.status': req.body.status
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    menu: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to update menu 1'));

            let menu = doc.menu.find(c => c.name === req.body.name);
            if (!menu) return next(new ErrorHandler(400, 'Error: Failed to update menu 2'));
            return res.status(200).json(menu);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to update menu'));
        }
    },

    delete: async function(req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'menu._id': req.params.id
            }, {
                $pull: {
                    menu: {
                        _id: req.params.id
                    }
                }
            }, {
                new: true, useFindAndModify: false, projection: {
                    menu: 1
                }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to delete menu 1'));
    
            let menu = doc.menu.find(c => c.id === req.params.id);
            if (!menu) return res.status(200).json({ id: req.params.id });
            return next(new ErrorHandler(400, 'Error: Failed to delete menu 2'));
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to delete menu'));
        }
    }

}