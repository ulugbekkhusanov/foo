const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');
const { TableSchema } = require('./../table/model');

const OrderSchema = new mongoose.Schema({
    store: { type: mongoose.Schema.Types.ObjectId },
    user: { type: mongoose.Schema.Types.ObjectId },
    table: { type: TableSchema, default: null },
    seats: { type: Number, default: 0 },
    checkin: String,
    checkout: String,
    status: String,
    payment: String,
    items: [{
        _id: false,
        product_id: mongoose.Schema.Types.ObjectId,
        product_name: { type: String, default: "" },
        product_price: { type: Number, default: 0 },
        quantity: { type: Number, default: 1 },
        total: { type: Number, default: 0 }
    }]
});
OrderSchema.plugin(normalize);
const OrderModel = mongoose.model('Order', OrderSchema, 'order');

module.exports = {
    OrderSchema,
    OrderModel
}