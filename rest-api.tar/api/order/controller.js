const { ErrorHandler } = require('../util/error');
const { OrderModel } = require('./model');

module.exports = {

    findAll: async function (req, res, next) {
        try {
            const docs = await OrderModel.find({
                store: req.identifier.store_id
            }, { store: 0 }).exec();

            return res.status(200).json(docs);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to read orders!'));
        }
    },

    create: async function (req, res, next) {
        try {
            req.body = Object.assign({}, req.body, {
                store: req.identifier.store_id,
                user: req.identifier.user_id
            })
            const order = new OrderModel(req.body);
            const doc = await order.save();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create order!'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await OrderModel.findByIdAndUpdate(req.params.id, req.body, {
                useFindAndModify: false, new: true
            }).exec();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to update order!'));
        }
    },

    delete: async function(req, res, next) {
        try {
            const doc = await OrderModel.findByIdAndDelete(req.params.id).exec();
            return res.status(200).json(doc);
        } catch (error) {
            return next(new ErrorHandler(400, "Exception: Failed to delete order!"));
        }
    }
}