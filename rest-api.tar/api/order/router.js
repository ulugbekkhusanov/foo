const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    upsert: {
        body: {
            table: Joi.any().allow(null).default(null),
            seats: Joi.number().min(0).default(0),
            checkin: Joi.string().allow('', null),
            checkout: Joi.string().allow('', null),
            status: Joi.string().allow('', null),
            payment: Joi.string().allow('', null),
            items: Joi.array().default([])
        }
    }
}

router.use(authenticate);
router.use(permit('user'));
router.route('/').get(controller.findAll);
router.route('/').post(validate(Validator.upsert), controller.create);
router.route('/:id').put(validate(Validator.upsert), controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;