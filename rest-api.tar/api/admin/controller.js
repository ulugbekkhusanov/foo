const jwt = require('jsonwebtoken');
const { ErrorHandler } = require('./../util/error');

module.exports = {
    auth: async function (req, res, next) {
        try {
            const { username, password } = req.body;

            if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
                const token = jwt.sign({
                    name: username,
                    role: 'admin'
                }, process.env.TOKEN_SECRET_KEY, {
                    algorithm: 'HS256',
                    expiresIn: process.env.TOKEN_EXPIRESIN
                });

                return res.status(200).json({
                    access_token: token
                });
            }
            return next(new ErrorHandler(401, "Error: Wrong credentials!"));

        } catch (err) {
            return next(new ErrorHandler(401, 'Exception Error: Authentication failed'));
        }
    }
};