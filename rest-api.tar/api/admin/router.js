const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const Validator = {
    auth: {
        body: {
            username: Joi.string().min(3).max(100).required(),
            password: Joi.string().min(3).max(100).required()
        }
    }
}

router.route('/auth').post(validate(Validator.auth), controller.auth);

module.exports = router;