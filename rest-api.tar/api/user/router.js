const express = require('express');
const router = express.Router();
const validate = require('express-validation');
const Joi = require('@hapi/joi');
const controller = require('./controller');

const authenticate = require('./../util/authenticate');
const permit = require('./../util/permission');

const Validator = {
    auth: {
        body: {
            storename: Joi.string().max(100).required(),
            user_pin: Joi.string().min(3).max(20).required()
        }
    },

    upsert: {
        body: {
            id: Joi.string(),
            name: Joi.string().min(3).max(100).required(),
            pin: Joi.string().min(3).max(20).required(),
            status: Joi.boolean().default(true),
            info: Joi.string().max(1000).allow(['', null])
        }
    }
}


router.route('/auth').post(validate(Validator.auth), controller.auth);

router.use(authenticate);
router.use(permit('store'));

router.route('/').get(controller.findAll);
router.route('/').post(validate(Validator.upsert), controller.create);
router.route('/:id').put(validate(Validator.upsert), controller.update);
router.route('/:id').delete(controller.delete);

module.exports = router;