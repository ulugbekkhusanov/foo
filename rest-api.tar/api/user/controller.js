const jwt = require('jsonwebtoken');
const bluebird = require('bluebird');
bluebird.promisifyAll(jwt);
const { ErrorHandler } = require('./../util/error');
const { StoreModel } = require('./../store/model');

module.exports = {
    auth: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOne({
                username: req.body.storename,
                status: true,
                account_balance: { $gt: 0 }
            }, { users: 1 }).exec();
            if(!doc) return next(new ErrorHandler(403, 'Error: User authentication failed'));
    
            let user = doc.users.find(u => u.pin === req.body.user_pin);
            if (!(user && user.status)) return next(new ErrorHandler(403, 'Error: Invalid pin!'));
    
            const token = jwt.sign({
                name: user.name,
                role: 'user',
                store_id: doc.id,
                user_id: user.id
            }, process.env.TOKEN_SECRET_KEY, {
                algorithm: 'HS256',
                expiresIn: process.env.TOKEN_EXPIRESIN
            });
    
            return res.status(200).json({
                access_token: token
            });
            
        } catch (error) {
            return next(new ErrorHandler(403, 'Exception Error: Forbidden access!'));
        }
    },

    findAll: async function (req, res, next) {
        try {
            const doc = await StoreModel.findById(req.identifier.store_id, { users: 1 }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to fetch users'));

            let result = doc.users || [];
            return res.status(200).json(result);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to fetch users'));
        }
    },

    create: async function (req, res, next) {
        try {
            const docTest = await StoreModel.findById(req.identifier.store_id, {
                users: 1,
                user_limit: 1
            }).exec();
            if (!docTest) return next(new ErrorHandler(400, 'Error: Failed to create user 1'));

            if (docTest.users.length >= docTest.user_limit) {
                return next(new ErrorHandler(400, 'Error: Failed to create user, limit is over'));
            }

            const doc = await StoreModel.findByIdAndUpdate(req.identifier.store_id, {
                $push: { users: req.body }
            }, {
                new: true, useFindAndModify: false, projection: { users: 1 }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to create user 2'));

            let user = doc.users.find(u => u.pin === req.body.pin);
            if (!user) return next(new ErrorHandler(400, 'Error: Failed to create user 3'));
            return res.status(200).json(user);
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to create user'));
        }
    },

    update: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'users._id': req.params.id
            }, {
                $set: {
                    'users.$.name': req.body.name,
                    'users.$.pin': req.body.pin,
                    'users.$.status': req.body.status,
                    'users.$.info': req.body.info,
                }
            }, {
                new: true, useFindAndModify: false, projection: { users: 1 }
            }).exec();
            if (!doc) return next(new ErrorHandler(400, 'Error: Failed to update user 1'));

            let user = doc.users.find(u => u.pin === req.body.pin);
            if (!user) return next(new ErrorHandler(400, 'Error: Failed to update user 2'));

            return res.status(200).json(user);

        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to update user'));
        }
    },

    delete: async function (req, res, next) {
        try {
            const doc = await StoreModel.findOneAndUpdate({
                _id: req.identifier.store_id,
                'users._id': req.params.id
            }, {
                $pull: {
                    users: {
                        _id: req.params.id
                    }
                }
            }, {
                new: true, useFindAndModify: false, projection: { users: 1 }
            }).exec();
            if(!doc) return next(new ErrorHandler(400, 'Error: Failed to delete user 1'));

            let user = doc.users.find(u => u.id === req.params.id);
            if (user) return next(new ErrorHandler(400, 'Error: Failed to delete user 2'));

            return res.status(200).json({ id: req.params.id });
            
        } catch (error) {
            return next(new ErrorHandler(400, 'Exception Error: Failed to delete user'));
        }
    }
}