const mongoose = require('mongoose');
const normalize = require('normalize-mongoose');

const UserSchema = new mongoose.Schema({
    name: { type: String, minlength: 3, maxlength: 100, required: true },
    pin: { type: String, minlength: 3, maxlength: 20, required: true },
    status: { type: Boolean, default: true },
    info: { type: String, maxlength: 1000, default: '' }
});

UserSchema.plugin(normalize);

const UserModel = mongoose.model('User', UserSchema, 'user');

module.exports = {
    UserSchema,
    UserModel
}